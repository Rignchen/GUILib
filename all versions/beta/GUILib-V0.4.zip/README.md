# GUILib
 Custom GUI datapack library
 Curently work in progress

 With this library you can now easily chose wich items can be in wich slot of a container just by setting some nbt into an entity, any item found in a slot where it shouldn't be will get kicked out of the container by the top